
from django.contrib import admin
from django.urls import path

from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index),
    path('index.html', views.index),
    path('about.html', views.about),
    path('do.html', views.do),
    path('portfolio.html', views.portfolio),
    path('contact.html', views.contact),

]